#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Mar  6 14:12:00 2021

@author: jack
"""

import numpy as np
import random

def RandomizeDronePosition(drone, magnitude):
    
    for i, null in enumerate(drone.state_vector):
        drone.state_vector[i] = random.uniform(-magnitude, magnitude)
        
    return drone